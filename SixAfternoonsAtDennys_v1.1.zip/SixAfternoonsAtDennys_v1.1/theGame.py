# This imports built-in modules
import sys
import os

# Here we import custom modules we made
gameFilesFolderPath = os.path.join(os.path.dirname(__file__), 'gameFiles')
sys.path.append(gameFilesFolderPath)

import userData
import inputCommands
import events
import univFunctions

# This is for the variable that starts the game
runGame = True

# The function that checks whatever you typed in the console.
def doCommand(command):
    if command == 'NOTHING':
        print()
    elif command == 'EXITGAME':
        global runGame
        runGame = False
    elif command == 'INVALID':
        print('Invalid Command')

# Title screen but it's text
print("\nSix Afternoon's at Denny's! by Kody Phommavongxay and Kunga Tsering \n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
print("\nRecommended to be played with the shell fully extended! ")
print("(Also try not to type in the shell unless it tells you to)\n")

# Resets stats at the beginning of the game
userData.askForName()

# Intro text
univFunctions.slowprint("{}? Well that sounds like a cool name! Let's get started. You are a tired warrior from Ohio. You found the One Piece and are exhausted. \nYou desire some Denny's!".format(userData.userStats[0]))
univFunctions.slowprint("So you decide to make a plan, to travel to six different Denny's located in Ohio. \nOn your crusade you meet a lot of different people, some good and some bad.")
univFunctions.slowprint("It is up to you {} to survive SIX AFTERNOON'S AT DENNY'S (you have ochestra practice after that day!)".format(userData.userStats[0]))

while runGame:
    print("\n")
    action = input('\nWhat would you like to do now? Type continue, check, rest, dance, or /exit ')
    if action[0] == '/':
        checkCommandReturn = inputCommands.checkCommand(action[1:])
        doCommand(checkCommandReturn)
    else:
        checkDialogueReturn = events.doEvent(action)

    if runGame == False:
        userData.resetStats()
        
        
        
