# imports
import combat
import interface
import univFunctions
import userData
import travel

# name variable
userName = userData.userStats[0]

# Kunga note: List of possible commands to do.
listOfActions = ['continue', 'check', 'rest', 'dance', '/exit']

# This is where I would add the interface for the code lol.
actCount = 0

#eventNum = 0 means before combat, eventNum = 1 means combat, eventNum = 2 means after combat
eventNum = 0
dayNum = 1

def morningTxt(day):
    global userName
    print()
    if day == 1:
        univFunctions.slowprint("It is {}'s first day, after traveling for hours they approach the first Denny's!".format(userName))
        univFunctions.slowprint("However, you come to see a middle aged dude bumbling about. You make eye contact from afar and he starts yelling. \nThen he starts to sprint towards you!")
        univFunctions.slowprint("The Basic Drunk: How bitter it is to see someone at Denny's! Nobody comes here! Only I do for the free stuff in the garbage! So buzz off!")
    elif day == 2:
        univFunctions.slowprint("It is the second day of {}'s adventure and the second Denny's location!".format(userName))
        univFunctions.slowprint("As you approach the second Denny you see a nice slab of sidewalk, it looks very clean. Once you step on it, you fumble off and see the sidewalk turn into something worse.")
        univFunctions.slowprint("The Slighty Disgruntled Golem: Hey, how dare you step on me! I am as clean as a whistle since no one comes here and now you step on me with your dirty foot! You have to pay for that!")
    
    elif day == 3:
        univFunctions.slowprint("At the dawn of the third day {}'s next Denny's over the horizon.".format(userName))
        univFunctions.slowprint("You reach the third Denny's with pride. You go inside and see someone stand there waiting for you outside the Denny's.")
        univFunctions.slowprint("The Neutral Drunk: You think you can eat at this Denny {}? I know who you are, I was sent to stop you by Denny himself. This is as far as you go!".format(userName))

    elif day == 4:
        univFunctions.slowprint("The sun rises on the fourth day of {}'s adventure. You can smell the bacon from miles away.".format(userName))
        univFunctions.slowprint("You see Denny is pretty close, but you also see an... IHOP? An IHOP next to a Denny's is strange, and what's stranger is a tall dude with a long chef hat approaches you.")
        univFunctions.slowprint("IHOP chef: So you like Denny's huh? Hmph! People like you make me sick, why can't you appreciate good food like IHOP? Well, I will show you a lesson!")
    elif day == 5:
        univFunctions.slowprint("{} nears the fifth Denny's with courage.".format(userName))
        univFunctions.slowprint("You see another person approach you. You are sighing at this and wonder what's new.")
        univFunctions.slowprint("The Acidic Drunk: You make me very sour, on your conquest to eat at Denny, however this is where it stops! Come, and taste the acidic taste of defeat!!!")
        
    elif day == 6:
        univFunctions.slowprint("It is the sixth day. {} gets an uneasy feeling about this Denny's location.".format(userName))
        univFunctions.slowprint("Denny: Well, well, well. Look who finally showed up. You have come a long way from home. But this is where your journey ends! Prepare for Denny himself!!!")
        

    print('\n')

def nightTxt(day):
    global userName
    print()
    if day == 1:
        univFunctions.slowprint("The Basic Drunk: I had too much to drink, I'm too bitter anyways.")
        univFunctions.slowprint("It is the end of the first day at Denny's.")
        univFunctions.slowprint("\nOur hero is tired and finds both a spa, a gym, and a casino. Where would you like to go?")

    elif day == 2:
        univFunctions.slowprint("The Slightly Disgruntled Golem: Hmph! I need a shower. Go touch some grass! ")
        univFunctions.slowprint("It is the end of the second day at Denny's.")
        univFunctions.slowprint("\nOur hero is tired and finds a spa, a gym, and a casino. Pretty nice. So, where would you like to go?")
        
    elif day == 3:
        univFunctions.slowprint("The Neutral Drunk: I need to go drink some water, that's more of my tasting.")
        univFunctions.slowprint("It is the end of the third day at Denny's.")
        univFunctions.slowprint("\nOur hero is tired after the fight and finds another spa, gym, and casino. Three in a row? Ohio is weird. I wonder where you would want to go?")
        
        
    elif day == 4:
        univFunctions.slowprint("IHOP chef: People like you don't deserve to eat good food!")
        univFunctions.slowprint("It is the end of the fourth day at Denny's.")
        univFunctions.slowprint("\nOur hero is tired after the fourth fight, man how many bad guys are there? You come across... ANOTHER SPA GYM *AND* CASINO? \nHow many are there?")                             
        
    elif day == 5:
        univFunctions.slowprint("The Acidic Drunk: Too sour for me, you are such a-mean-o acid!")
        univFunctions.slowprint("It is the end of the fifth day at Denny's.")
        univFunctions.slowprint("\nLow and behold another spa, gym, and casino, who would have thought?")
        
    elif day == 6:
        univFunctions.slowprint("Denny: Please, just don't take the Cali Club Sandwhich! It's all I have...")
        univFunctions.slowprint("It is the end of the sixth day at Denny's.")
    
        # Win text
        univFunctions.slowprint("Wait... you have defeated Denny and his empire. Congratulations!")
        univFunctions.slowprint("You felt sort of bad for beating up everyone... Nah you really don't.")
        univFunctions.slowprint("You made it back in time for ochestra practice!")
        quit()
    print('\n')
    travel.doTravel()
    
    
danceCount = 0

def doEvent(action):
    global userName
    userName = userData.userStats[0]

    global eventNum
    global dayNum
    global danceCount
    
    
    if action.lower() == 'continue':
        if dayNum == 7:
            # put the game win text here
            pass
        eventNum = 0
        # eventNum indicates which part of the day it is
        while eventNum < 3:
            #print('eventNum:',eventNum)
            #print('dayNum:',dayNum)

            # before combat phase
            if eventNum == 0:
                
                morningTxt(dayNum)
            # combat phase
            elif eventNum == 1: 
                
                combat.battleFunction(dayNum - 1)
            
                if combat.userDead:
                    #print('lose')
                    univFunctions.slowprint('You died, you no longer can eat at Denny\'s')
                    # -----------> game over function/text here <-------
                    quit()
                #return 'COMBAT'

            # post-combat phase
            else:
                nightTxt(dayNum)
                dayNum += 1

            # changes day phase
            eventNum += 1
            
    # once the day ends this stuff becomes available
    elif action == 'dance':
        if danceCount == 0:
            univFunctions.slowprint("You danced in place and nothing happened, you look cool though. Try typing continue instead of dance.")
            danceCount += 1
        elif danceCount == 1:
            univFunctions.slowprint("You danced in place and nothing happened, again... try typing continue instead of dance...")
            danceCount += 1
        elif danceCount == 2:
            univFunctions.slowprint("You danced in place and nothing happened... dude it isn't hard just type 'continue'. ")
            danceCount += 1
        elif danceCount == 3:
            univFunctions.slowprint("AUGH I GIVE UP. you danced in place and yadda yadda nothing happened... just make it up yourself. ")
            danceCount += 1
        else:
            univFunctions.slowprint("... (you imagined yourself dancing)...")
        
        
    elif action == 'rest':
        univFunctions.slowprint('You rest for a little bit at the Reef and wake up feeling refreshed from Johnnie bread.')
        combat.userStats.userHP = combat.userStats.userMaxHP
        univFunctions.slowprint("You now have {} health points!".format(combat.userStats.userHP))
        #print('Current Health: {}, Max Health {}'.format(userData.userStats[1],userData.userStats[2]))
    elif action == 'check':
        interface.statistics()
        univFunctions.slowprint("Here are some nice juicy stats! Wowza look at that!")
        
    else:
        univFunctions.slowprint("I don't think the protagonist understood what you are saying, try using these commands! {}".format(str(listOfActions).strip('][')))


