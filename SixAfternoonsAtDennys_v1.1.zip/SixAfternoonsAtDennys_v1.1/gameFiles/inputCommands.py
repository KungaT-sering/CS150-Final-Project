# imports
import userData

def checkCommand(command):
    # exit command
    global userData
    if command == 'exit':
        confirmClose = input('\nExit the game? Enter "yes" to confirm. (Unsaved data will be lost)\n')
        if confirmClose == 'yes':
            print('Closing game...')
            return 'EXITGAME'
    else:
        return 'INVALID'