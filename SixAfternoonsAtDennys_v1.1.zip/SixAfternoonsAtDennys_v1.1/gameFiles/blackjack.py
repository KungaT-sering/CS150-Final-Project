import random
import time
import univFunctions

class varsClass:
    dealer = []
    dCards = []
    player = []
    pCards = []
    dTotal = 0
    pTotal = 0
    pBust = False
    dBust = False

global vars
vars = varsClass

def dealerDraw():
    dNew = random.randint(1,13)
    if dNew > 10:
        if dNew == 11:
            vars.dCards.append('J')
        elif dNew == 12:
            vars.dCards.append('Q')
        elif dNew == 13:
            vars.dCards.append('K')
        dNew = 10
    else:
        vars.dCards.append(str(dNew))
    vars.dealer.append(dNew)
    vars.dTotal = sum(vars.dealer)
    if 1 in vars.dealer and vars.dTotal <= 11:
        vars.dTotal += 10

def playerDraw():
    pNew = random.randint(1,13)
    if pNew > 10:
        if pNew == 11:
            vars.pCards.append('J')
        elif pNew == 12:
            vars.pCards.append('Q')
        elif pNew == 13:
            vars.pCards.append('K')
        pNew = 10
    else:
        vars.pCards.append(str(pNew))
    vars.player.append(pNew)
    vars.pTotal = sum(vars.player)
    if 1 in vars.player and vars.pTotal <= 11:
        vars.pTotal += 10

def blackjack():
    sleepTime = 0.7
    playing = True
    playerTurn = True
    textJoinSeparator = ", "
    while playing:
        vars.dealer = []
        vars.dCards = []
        vars.player = []
        vars.pCards = []
        vars.dTotal = 0
        vars.pTotal = 0
        vars.pBust = False
        vars.dBust = False

        for i in range(0,2):
            dealerDraw()

        for j in range(0,2):
            playerDraw()
        
        

        while playerTurn:
            cardsTxt = textJoinSeparator.join(vars.pCards)
            #univFunctions.slowprint(vars.player)
            univFunctions.slowprint("\nYour cards are {}".format(cardsTxt))
            univFunctions.slowprint("Your total is {}".format(vars.pTotal))
            if vars.pTotal > 21:
                vars.pBust = True
                playerTurn = False
                univFunctions.slowprint('\nPlayer busts! Dealer Wins!')
            if not vars.pBust:
                # hit or stand
                turn = input('\nHit or Stand? ')
                while turn.lower() != 'hit' and turn.lower() != 'stand':
                    univFunctions.slowprint('Invalid Response')
                    turn = input('\nHit or Stand? ')
                if turn.lower() == 'hit':
                    # draws new card
                    playerDraw()
                    univFunctions.slowprint('\nYou drew a {}'.format(vars.pCards[-1]))
                    time.sleep(0.5)
                    # makes ace equal 11 when necessary
                elif turn.lower() == 'stand':
                    playerTurn = False
            

        while not playerTurn and not vars.pBust and not vars.dBust:
            time.sleep(sleepTime)
            #univFunctions.slowprint(vars.dealer)
            cardsTxt = textJoinSeparator.join(vars.dCards)
            univFunctions.slowprint("\nDealer's cards are {}".format(cardsTxt))
            univFunctions.slowprint("The dealer has {}".format(vars.dTotal))
            # dealer plays while it has
            while not (17 <= vars.dTotal <= 21) and not vars.dBust and vars.dTotal < vars.pTotal:
                univFunctions.slowprint('\nDealer hits...')
                time.sleep(sleepTime)
                # dealer plays
                dealerDraw()
                univFunctions.slowprint('\nDealer drew a {}'.format(vars.dCards[-1]))
                # univFunctions.slowprints dealer's cards
                cardsTxt = textJoinSeparator.join(vars.dCards)
                univFunctions.slowprint("\nDealer's cards are {}".format(cardsTxt))
                univFunctions.slowprint("The dealer has {}".format(vars.dTotal))
                # dealer bust
                if vars.dTotal > 21:
                    time.sleep(sleepTime)
                    univFunctions.slowprint("\nDealer Busts! You Win!")
                    vars.dBust = True
            # if 17 <= dealer <= 21
            if not vars.dBust:    
                time.sleep(sleepTime)
                if vars.dTotal > vars.pTotal:
                    univFunctions.slowprint('\nDealer Wins!')
                elif vars.dTotal == vars.pTotal:
                    univFunctions.slowprint('\nIt\'s a Tie!')
                else:
                    univFunctions.slowprint('\nYou Win!')
            playerTurn = True

        # Play again or no
        time.sleep(sleepTime)
        playAgain = input('\nPlay again? (yes or no) ')
        while playAgain.lower() != 'no' and playAgain.lower() != 'yes':
            univFunctions.slowprint('Invalid Response')
            playAgain = input('\nPlay again? (yes or no) ')
        if playAgain == 'no':
            # end the program
            univFunctions.slowprint('\nWell that was a night well spent!')
            time.sleep(sleepTime)
            playing = False
        elif playAgain == 'yes':
            # reset
            univFunctions.slowprint('\nStarting new round...')
            vars.dealer = []
            vars.dCards = []
            vars.player = []
            vars.pCards = []
            vars.dTotal = 0
            vars.pTotal = 0
            vars.pBust = False
            vars.dBust = False
            time.sleep(1)