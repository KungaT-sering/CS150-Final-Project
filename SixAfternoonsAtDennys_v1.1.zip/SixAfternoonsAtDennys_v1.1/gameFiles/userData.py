userStats = ['Name',20.0,20.0,10.0,10.0]
# UserStats is now a list


def askForName():
    name = input("What is the hero's name? ")
    global userStats
    userStats[0] = name