# This is the interface that the user can use / call upon to look at their stats during the game!

import userData
import combat
import univFunctions

def statistics():
    print()
    univFunctions.slowprint(userData.userStats[0]+":")
    univFunctions.slowprint("Current health: " + str(combat.userStats.userHP) + "/" + str(combat.userStats.userMaxHP))
    univFunctions.slowprint("Damage: " + str(combat.userStats.userDmg))
    univFunctions.slowprint("Defense: " + str(combat.userStats.userDef))
    
def statisticsEnemy():
    print()
    univFunctions.slowprint("{}: ".format(str(combat.enemyStats.enemyName)))
    univFunctions.slowprint("Current health: " + str(combat.enemyStats.enemyHP) + "/" + str(combat.enemyStats.enemyMaxHP))
    univFunctions.slowprint("Damage: " + str(combat.enemyStats.enemyDmg))
    univFunctions.slowprint("Defense: " + str(combat.enemyStats.enemyDef))
    