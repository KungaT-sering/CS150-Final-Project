# imports
import random
import userData
import enemies
import univFunctions
import interface

# A class for what a user will be along with loading them.
class userStatsClass:
    userName = str(userData.userStats[0])
    userHP = int(userData.userStats[1])
    userMaxHP = int(userData.userStats[2])
    userDmg = int(userData.userStats[3])
    userDef = int(userData.userStats[4])

global userStats
userStats = userStatsClass()

def loadStats():
    userStats.userName = str(userData.userStats[0])
    userStats.userHP = int(userData.userStats[1])
    userStats.userMaxHP = int(userData.userStats[2])
    userStats.userDmg = int(userData.userStats[3])
    userStats.userDef = int(userData.userStats[4])

# List of all possible moves to do in combat
playerMoves = ['swing','pan','throw','heal','kiss','dance','check','help'] # player moves MUST be all lowercase, no punctuation


# The setup for the enemy stats along with loading them as well.
class enemyStatsClass:
    enemyName = 0
    enemyHP = 0
    enemyMaxHP = 0
    enemyDmg = 0
    enemyDef = 0

global enemyStats
enemyStats = enemyStatsClass()

class combatVariables:
    guard = 0
    inBattle = False 
    isPlayerTurn = False
    enemyDead = True

global combatVars
combatVars = combatVariables()

userDead = False

def createEnemy(enemyNum):
    enemyStats.enemyName = str(enemies.enemyLists.enemiesNames[enemyNum])
    enemyStats.enemyHP = int(enemies.enemyLists.enemiesHP[enemyNum])
    enemyStats.enemyMaxHP = int(enemies.enemyLists.enemiesMaxHP[enemyNum])
    enemyStats.enemyDmg = int(enemies.enemyLists.enemiesDmg[enemyNum])
    enemyStats.enemyDef = int(enemies.enemyLists.enemiesDef[enemyNum])

# test battle setup
inBattle = False
isPlayerTurn = True
enemyDead = False
trueThenAlive = False

# Here is a function for when it is your turn to attack.
def combatPlayerTurn():
    
    playerAction = input('\nWhat should {} do? '.format(userStats.userName))
    playerAction = playerAction.lower()
    
    # If you need help, this will do.
    while playerAction == 'help':
        univFunctions.slowprint('Here are all of the moves you can use during combat. \n')
        univFunctions.slowprint("- 'swing' will do a low amount of damage with a low chance to miss.")
        univFunctions.slowprint("- 'throw' will do a medium amount of damage with a medium chance to miss.")
        univFunctions.slowprint("- 'pan' will do a high amount of damage with a high chance to miss.")
        univFunctions.slowprint("- 'heal' will heal yourself from 1 to 15 HP, but costing your turn.")
        univFunctions.slowprint("- 'kiss' will have a chance to stun your opponents, the chance is not high, but you never know.")
        univFunctions.slowprint("- 'dance'... okay...")
        univFunctions.slowprint("- 'check' will display stats during battle, will not cost your turn.\n")
        
        playerAction = input('What should {} do? '.format(userStats.userName))
    
    # If what you type is not in the playerMoves it will loop until you do
    while playerAction not in playerMoves:
        univFunctions.slowprint('\nInvalid input, available moves are {}'.format(str(playerMoves).strip("][")))
        playerAction = input('What should {} do? '.format(userStats.userName))
    
        
    if playerAction in playerMoves:
        
        # Move called swing, does normal damage with small chance to miss
        if playerAction == 'swing':
            randomHit = random.randint(0,17)
            if randomHit > 1:
                playerDamageDealt = userStats.userDmg
                if playerDamageDealt < 0:
                    playerDamageDealt = 0
                enemyStats.enemyHP -= playerDamageDealt
                univFunctions.slowprint('\n{} swings at {} with a spatula! That has to hurt tommorrow.'.format(userStats.userName,enemyStats.enemyName))
                univFunctions.slowprint('{} dealt {:.2f} damage to {}'.format(userStats.userName,playerDamageDealt,enemyStats.enemyName))
            elif randomHit == 0:
                playerDamageDealt = 0
                univFunctions.slowprint('\n{} swings at {} with a spatula... but could not manage to even lift it up! Need to implement core in your next gym session...'.format(userStats.userName,enemyStats.enemyName))
                univFunctions.slowprint('{} dealt {:.2f} damage to {}'.format(userStats.userName, playerDamageDealt,enemyStats.enemyName))
            
        # Move called pan, 60% chance to do a lot of damage, but a chance of missing that will deal self damage.
        elif playerAction == 'pan':
            univFunctions.slowprint('\n{} grabs a frying pan, and jumps at {}!'.format(userStats.userName,enemyStats.enemyName))
            randomHit = random.randint(1,5)
            if randomHit <= 3:
                playerDamageDealt = userStats.userDmg * 1.5
                if playerDamageDealt < 0:
                    playerDamageDealt = 0
                enemyStats.enemyHP -= playerDamageDealt
                univFunctions.slowprint('\n{} successfully struck the enemy!'.format(userStats.userName))
                univFunctions.slowprint('{} dealt {:.2f} damage to {}'.format(userStats.userName,playerDamageDealt,enemyStats.enemyName))
            else:
                playerDamageDealt = 0
                univFunctions.slowprint('\n{} fell down and missed completely scrapping their knee.'.format(userStats.userName))
                userStats.userHP -= 2
                univFunctions.slowprint('{} dealt {:.2f} damage to {}'.format(userStats.userName, playerDamageDealt,enemyStats.enemyName))
        
        # Move called throw, you basically throw a plate at the enemy with a chance to hit. Has 2/3 chance to do 1.2x damage
        elif playerAction == 'throw':
            univFunctions.slowprint('\n{} throws a plate and snipes {} from afar! '.format(userStats.userName,enemyStats.enemyName))
            randomHit = random.randint(0,2)
            if randomHit != 2:
                playerDamageDealt = userStats.userDmg * 1.2
                if randomHit == 0:
                    if playerDamageDealt < 0:
                        playerDamageDealt = 0
                    enemyStats.enemyHP -= playerDamageDealt
                    univFunctions.slowprint('\n{} hit the enemy!'.format(userStats.userName))
                    univFunctions.slowprint('{} dealt {:.2f} damage to {}'.format(userStats.userName,playerDamageDealt,enemyStats.enemyName))
                if randomHit == 1:
                    if playerDamageDealt < 0:
                        playerDamageDealt = 0
                    enemyStats.enemyHP -= playerDamageDealt
                    univFunctions.slowprint('\n{} hit the enemy!'.format(userStats.userName))
                    univFunctions.slowprint('{} dealt {:.2f} damage to {}'.format(userStats.userName,playerDamageDealt,enemyStats.enemyName))
            else:
                playerDamageDealt = 0
                univFunctions.slowprint('\n... wait actually I think you hit professor Bob...')
                univFunctions.slowprint('{} missed the enemy.'.format(userStats.userName))
                univFunctions.slowprint('{} dealt {:.2f} damage to {}'.format(userStats.userName, playerDamageDealt,enemyStats.enemyName))

        # Move called dance, that is more of a joke that wastes your turn.
        elif playerAction == 'dance':
            univFunctions.slowprint("You danced around in place and nothing happened. You look like a fool, don't dance during combat!!!")
           
        # Move called kiss, a silly move that has a small chance of beating the enemy by kissing. Not an effective way to fight but still.
        elif playerAction == 'kiss':
            randomHit = random.randint(1,10)
            if randomHit != 1:
                univFunctions.slowprint("You leaned forward and went for a kiss. You both ended up kissing each other and... nothing happened. They were shocked but honestly, what did you expect? ")
            else:
                univFunctions.slowprint("You leaned forward and went for a kiss. You both ended up kissing each other and... {} blushed! The enemy retreated! ".format(enemyStats.enemyName))
                enemyStats.enemyHP = 0
        
        # Move called heal, you basically regain a certain amount of HP based on luck.
        elif playerAction == 'heal':
            healAmount = random.randint(1,15)
            userStats.userHP += healAmount
            if userStats.userHP > userStats.userMaxHP:
                healDiff = userStats.userHP - userStats.userMaxHP
                userStats.userHP = userStats.userHP - healDiff
            if healAmount > 10:
                univFunctions.slowprint("Wow you pulled into your bag and pulled out a Flamin' 5-Pepper Burger from Denny's! You ate it and healed {} HP! ".format(healAmount))
            elif healAmount > 5:
                univFunctions.slowprint("You pulled in your bag and pulled out a Slamburger from Denny's. It wasn't too bad and you healed {} HP. ".format(healAmount))
            else:
                univFunctions.slowprint("You looked into your bag and grabbed a Smoked House Combo from IHOP. It tasted terrible, but you healed {} HP. ".format(healAmount))
    
    if enemyStats.enemyHP <= 0:
        combatVars.enemyDead = True
        combatVars.inBattle = False  
        univFunctions.slowprint('The enemy has been defeated!\n')
        
    if enemyStats.enemyHP > 0:
        univFunctions.slowprint("\n{} has {:.2f}/{:.2f} HP remaining \n{} has {:.2f}/{:.2f} HP remaining".format(userStats.userName, userStats.userHP, userStats.userMaxHP, enemyStats.enemyName, enemyStats.enemyHP, enemyStats.enemyMaxHP))
    
    combatVars.isPlayerTurn = False


# Function for when it is the enemy's turn.
def combatEnemyTurn():
    global userDead
    
    # If Denny
    if enemyStats.enemyName == 'Denny' and enemyStats.enemyHP <= enemyStats.enemyMaxHP * .5:
        dennyChance = random.randint(0,1)
        if dennyChance == 0:
            univFunctions.slowprint("Denny: FEEL THE WRATH OF DENNY!")
            univFunctions.slowprint('\n{} attacks {} with a mysterious force that cannot be explained!'.format(enemyStats.enemyName,userStats.userName))
            enemyDamageDealt = (enemyStats.enemyDmg * 1.7) - combatVars.guard
            if enemyDamageDealt < 0:
                enemyDamageDealt = 0
            userStats.userHP -= enemyDamageDealt
            univFunctions.slowprint('{} dealt {:.2f} damage to {}!'.format(enemyStats.enemyName,enemyDamageDealt,userStats.userName))
            univFunctions.slowprint('{} has {:.2f} health remaining.'.format(userStats.userName,userStats.userHP))
            if userStats.userHP <= 0:
                combatVars.inBattle = False
                univFunctions.slowprint('{} has died!'.format(userStats.userName))
                
                userDead = True
            combatVars.isPlayerTurn = True

        elif dennyChance == 1:
            univFunctions.slowprint("Denny: FEEL THE WRATH OF DENNY!!!")
            univFunctions.slowprint("Denny's rage caused him to miss.")
            enemyDamageDealt = 0
            if userStats.userHP <= 0:
                combatVars.inBattle = False

                univFunctions.slowprint('{} has died!'.format(userStats.userName))
                
                userDead = True
            combatVars.isPlayerTurn = True

        # reset guard
        combatVars.guard = 0            
    else:
        # If NOT Denny
        univFunctions.slowprint('\n{} attacks {}'.format(enemyStats.enemyName,userStats.userName))
        enemyDamageDealt = (enemyStats.enemyDmg + (enemyStats.enemyDmg * 0.2)) - combatVars.guard
        
        if enemyDamageDealt < 0:
            enemyDamageDealt = 0
        userStats.userHP -= enemyDamageDealt

        univFunctions.slowprint('{} dealt {:.2f} damage to {}.'.format(enemyStats.enemyName,enemyDamageDealt,userStats.userName))
        univFunctions.slowprint('{} has {:.2f} health remaining.'.format(userStats.userName,userStats.userHP))
        if userStats.userHP <= 0:
            combatVars.inBattle = False

            univFunctions.slowprint('{} has died!'.format(userStats.userName))
    
            userDead = True
        combatVars.isPlayerTurn = True

        # reset guard
        combatVars.guard = 0
    
# main battle function
def battleFunction(enemyNum):
    loadStats()
    global userDead
    userDead = False

    # create enemy
    createEnemy(enemyNum)
    combatVars.inBattle = True 
    combatVars.isPlayerTurn = True
    combatVars.enemyDead = False
    
    univFunctions.slowprint("{} approaches!".format(enemyStats.enemyName))
    
    interface.statistics()
    interface.statisticsEnemy()
    while combatVars.inBattle == True:
    # enemy turn
        combatVars.guard = 0
        if combatVars.isPlayerTurn == True:
            combatPlayerTurn()
        else:
            combatEnemyTurn() 