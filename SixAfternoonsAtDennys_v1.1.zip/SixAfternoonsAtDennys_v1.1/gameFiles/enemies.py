# Reads the csv file to get enemy data
enemiesDataFile = open('gameFiles/enemiesData.csv','r')
enemiesDataRead = enemiesDataFile.read()
enemiesDataFile.close()
enemiesDataList = enemiesDataRead.split('\n')
#print(enemiesDataList)

class enemyListsClass:
    enemiesNames = []
    enemiesHP = []
    enemiesMaxHP = []
    enemiesDmg = []
    enemiesDef = []

global enemyLists
enemyLists = enemyListsClass()

def createEnemyLists():
    for i in range(len(enemiesDataList)):
        enemyStats = enemiesDataList[i].split(',')
        if (len(enemyStats) == 5) and ('' not in enemyStats) and (enemyStats[0] not in enemyLists.enemiesNames):
            enemyLists.enemiesNames.append(enemyStats[0])
            enemyLists.enemiesHP.append(enemyStats[1])
            enemyLists.enemiesMaxHP.append(enemyStats[2])
            enemyLists.enemiesDmg.append(enemyStats[3])
            enemyLists.enemiesDef.append(enemyStats[4])

# Testing
createEnemyLists()


    