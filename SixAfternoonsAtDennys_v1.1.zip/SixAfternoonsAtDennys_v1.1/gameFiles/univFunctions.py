# imports
import sys
import time

# variables
sleepTime = 0.015

def slowprint(s):
    for c in s + '\n':
        sys.stdout.write(c)
        sys.stdout.flush()
        global sleepTime
        time.sleep(sleepTime)
