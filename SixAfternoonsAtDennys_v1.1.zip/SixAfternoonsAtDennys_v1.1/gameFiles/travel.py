# Imports
import userData
import univFunctions

import random
import blackjack

locations = ['spa','gym','casino','home']


def doTravel():
    userName = userData.userStats[0]
    # User inputs where to go
    univFunctions.slowprint("Available Locations:")
    for place in locations:
        print("-",place)
    print()
    travelTo = input("What do you think? ")
    # Keep asking until valid location
    while travelTo not in locations:
        print("\nInvalid Location\n")
        univFunctions.slowprint("Available Locations:")
        for place in locations:
            print("-",place)
        print()
        travelTo = input("What do you think? ")

    travelTo = travelTo.lower()

    if travelTo == 'spa':
        univFunctions.slowprint("{} went to the spa to wind down after the battle.".format(userName))

        incHP = random.randint(4,6)
        userData.userStats[1] += incHP
        userData.userStats[2] += incHP
        univFunctions.slowprint("{}'s max health increased by {}!".format(userName,incHP))

    elif travelTo == 'gym':
        univFunctions.slowprint("{} went to the gym and trained to become stronger.".format(userName))

        incDmg = random.randint(1,2)
        userData.userStats[3] += incDmg
        univFunctions.slowprint("{}'s damage increased by {}!".format(userName,incDmg))

    elif travelTo == 'casino':
        univFunctions.slowprint("{} went to the casino for some well deserved blackjack.".format(userName))
        blackjack.blackjack()
    elif travelTo == 'home':
        univFunctions.slowprint("{} goes home to prepare for their next Denny's.".format(userName))
    else:
        print("something went wrong")